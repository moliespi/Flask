class User:
    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password = password

    @classmethod
    def check_password(cls, hashed_password, password):
        return hashed_password == password
