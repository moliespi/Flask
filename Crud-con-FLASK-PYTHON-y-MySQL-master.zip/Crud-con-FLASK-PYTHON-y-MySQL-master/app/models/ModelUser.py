from .entities.User import User

class ModelUser:

    @classmethod
    def login(self, mysql, user):
        try:
            cursor = mysql.connection.cursor()
            sql = "SELECT id, username, password FROM user WHERE username = %s"
            cursor.execute(sql, (user.username,))
            data = cursor.fetchone()

            if data is not None:
                found_user = User(data[0], data[1], User.check_password(data[2], user.password))
                return found_user
            else:
                return None
        except Exception as ex:
            raise Exception(ex)
